/*
 Navicat Premium Data Transfer

 Source Server         : test
 Source Server Type    : MySQL
 Source Server Version : 50719
 Source Host           : localhost:3306
 Source Schema         : zhouzhou

 Target Server Type    : MySQL
 Target Server Version : 50719
 File Encoding         : 65001

 Date: 16/08/2020 17:18:35
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin`  (
  `id` int(11) NOT NULL,
  `adminname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `adminpassword` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for contact
-- ----------------------------
DROP TABLE IF EXISTS `contact`;
CREATE TABLE `contact`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `contact` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of contact
-- ----------------------------
INSERT INTO `contact` VALUES (5, NULL, '111', '120573605@qq.com', '111', '312321');
INSERT INTO `contact` VALUES (6, NULL, '321312', '120573605@qq.com', '1232132132131', '21321312312');

-- ----------------------------
-- Table structure for img
-- ----------------------------
DROP TABLE IF EXISTS `img`;
CREATE TABLE `img`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` longblob NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for love
-- ----------------------------
DROP TABLE IF EXISTS `love`;
CREATE TABLE `love`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `moive` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 18 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of love
-- ----------------------------
INSERT INTO `love` VALUES (3, '2020-08-07 16:18:27', '123', NULL);
INSERT INTO `love` VALUES (13, '2020-08-16 16:20:20', 'Knives Out \n', 'zz');
INSERT INTO `love` VALUES (14, '2020-08-16 16:41:15', 'Gisaengchung', 'zz');
INSERT INTO `love` VALUES (15, '2020-08-16 16:41:16', 'Joker', 'zz');
INSERT INTO `love` VALUES (16, '2020-08-16 16:41:19', 'Uncut Gems', 'zz');
INSERT INTO `love` VALUES (17, '2020-08-16 16:41:21', 'Avengers: Endgame', 'zz');

-- ----------------------------
-- Table structure for moive
-- ----------------------------
DROP TABLE IF EXISTS `moive`;
CREATE TABLE `moive`  (
  `id` int(11) NOT NULL,
  `view` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `booking` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `date` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `uri` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `genre` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of moive
-- ----------------------------
INSERT INTO `moive` VALUES (1, '3003', '1503', '7', 'Knives Out \r\n', 'MV1.jpg', 'Sci-Fi');
INSERT INTO `moive` VALUES (2, '1400', '238', '45', 'Ford v Ferrari', 'MV2.jpg', 'Action');
INSERT INTO `moive` VALUES (3, '3513', '367', '23', 'Once Upon a Time... in Hollywood ', 'MV3.jpg', 'Action');
INSERT INTO `moive` VALUES (4, '5302', '789', '14', 'Gisaengchung', 'MV4.jpg', 'Action');
INSERT INTO `moive` VALUES (5, '4132', '325', '3', 'Joker', 'MV5.jpg', 'Action');
INSERT INTO `moive` VALUES (6, '4565', '1237', '17', 'Uncut Gems', 'MV6.jpg', 'Comedy');
INSERT INTO `moive` VALUES (7, '6782', '3473', '35', '1917', 'MV7.jpg', 'Comedy');
INSERT INTO `moive` VALUES (8, '7002', '2930', '23', 'Midsommar', 'MV8.jpg', 'Comedy');
INSERT INTO `moive` VALUES (9, '3283', '982', '12', 'Avengers: Endgame', 'MV9.jpg', 'Horror');
INSERT INTO `moive` VALUES (10, NULL, NULL, NULL, 'Knive fuck', NULL, NULL);

-- ----------------------------
-- Table structure for shoucang
-- ----------------------------
DROP TABLE IF EXISTS `shoucang`;
CREATE TABLE `shoucang`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `moivename` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `date` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for ticket
-- ----------------------------
DROP TABLE IF EXISTS `ticket`;
CREATE TABLE `ticket`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `date` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `uri` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ticket
-- ----------------------------
INSERT INTO `ticket` VALUES (9, 'zz', '2020-08-10 16:46:23', 'Two-screens.jpg');
INSERT INTO `ticket` VALUES (10, 'zz', '2020-08-16 16:41:36', 'Two-screens.jpg');
INSERT INTO `ticket` VALUES (11, NULL, '2020-08-16 17:02:05', 'Two-screens.jpg');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sex` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `bankcard` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, 'zz', '123', '123', '20192204229@stu.kust.edu.cn', '123', '12341512321312');
INSERT INTO `user` VALUES (2, 'xcz', '321', NULL, NULL, NULL, NULL);
INSERT INTO `user` VALUES (3, 'xxx', '1234567', NULL, NULL, NULL, NULL);
INSERT INTO `user` VALUES (4, 'aman', '123456', NULL, NULL, NULL, NULL);
INSERT INTO `user` VALUES (5, 'aman2', '123456', NULL, NULL, NULL, NULL);
INSERT INTO `user` VALUES (7, '1233', '31233', NULL, NULL, NULL, NULL);
INSERT INTO `user` VALUES (8, '1234567', '123444444', NULL, NULL, NULL, NULL);
INSERT INTO `user` VALUES (9, '31234124', '213123123', NULL, NULL, NULL, NULL);
INSERT INTO `user` VALUES (10, '1234567', '123', NULL, NULL, NULL, NULL);
INSERT INTO `user` VALUES (11, '12421421', '4214214', NULL, NULL, NULL, NULL);

-- ----------------------------
-- Table structure for userhistory
-- ----------------------------
DROP TABLE IF EXISTS `userhistory`;
CREATE TABLE `userhistory`  (
  `id` int(11) NOT NULL,
  `userid` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Moiveid` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `rate` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `simnum` double(255, 0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of userhistory
-- ----------------------------
INSERT INTO `userhistory` VALUES (1, 'zz', '1', '4.5', NULL);
INSERT INTO `userhistory` VALUES (2, 'zz', '2', '2.5', NULL);
INSERT INTO `userhistory` VALUES (3, 'zz', '3', '1.0', NULL);
INSERT INTO `userhistory` VALUES (4, 'zz', '4', '3.5', NULL);
INSERT INTO `userhistory` VALUES (5, 'zz', '5', '4.5', NULL);
INSERT INTO `userhistory` VALUES (6, 'zz', '6', '5.0', NULL);
INSERT INTO `userhistory` VALUES (7, 'xcz', '1', '4.5', NULL);
INSERT INTO `userhistory` VALUES (8, 'xcz', '3', '2.5', NULL);
INSERT INTO `userhistory` VALUES (9, 'xcz', '5', '1.0', NULL);
INSERT INTO `userhistory` VALUES (10, 'xcz', '7', '4.5', NULL);
INSERT INTO `userhistory` VALUES (11, 'xcz', '9', '4.5', NULL);
INSERT INTO `userhistory` VALUES (12, 'xcz', '2', '2.0', NULL);
INSERT INTO `userhistory` VALUES (13, 'qfg', NULL, NULL, NULL);
INSERT INTO `userhistory` VALUES (14, NULL, NULL, NULL, NULL);
INSERT INTO `userhistory` VALUES (15, NULL, NULL, NULL, NULL);
INSERT INTO `userhistory` VALUES (16, NULL, NULL, NULL, NULL);
INSERT INTO `userhistory` VALUES (17, NULL, NULL, NULL, NULL);
INSERT INTO `userhistory` VALUES (18, NULL, NULL, NULL, NULL);
INSERT INTO `userhistory` VALUES (19, NULL, NULL, NULL, NULL);
INSERT INTO `userhistory` VALUES (20, NULL, NULL, NULL, NULL);
INSERT INTO `userhistory` VALUES (21, NULL, NULL, NULL, NULL);
INSERT INTO `userhistory` VALUES (22, NULL, NULL, NULL, NULL);
INSERT INTO `userhistory` VALUES (23, NULL, NULL, NULL, NULL);
INSERT INTO `userhistory` VALUES (24, NULL, NULL, NULL, NULL);
INSERT INTO `userhistory` VALUES (25, NULL, NULL, NULL, NULL);
INSERT INTO `userhistory` VALUES (26, NULL, NULL, NULL, NULL);
INSERT INTO `userhistory` VALUES (27, NULL, NULL, NULL, NULL);
INSERT INTO `userhistory` VALUES (28, NULL, NULL, NULL, NULL);
INSERT INTO `userhistory` VALUES (29, NULL, NULL, NULL, NULL);
INSERT INTO `userhistory` VALUES (30, NULL, NULL, NULL, NULL);

-- ----------------------------
-- Table structure for userinfo
-- ----------------------------
DROP TABLE IF EXISTS `userinfo`;
CREATE TABLE `userinfo`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NULL DEFAULT NULL,
  `sex` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `emai` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `bankcard` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
