package com.sang.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Map.Entry;


public class RecommendTest {
	

	public RecommendTest() {
		initData();
	}
	//设置公共字典
	private Map<String, Map<String, Double>> dataset = null;
	//初始化方法调用

	//数据集调用
	private void initData() {
		dataset = new HashMap<String, Map<String, Double>>();
		
		
		// 初始化p1 数据集
		
		Map<String, Double> roseMap = new HashMap<String, Double>();
		roseMap.put("movie1", 4.5);
		roseMap.put("movie2", 2.5);
		roseMap.put("movie3", 1.0);
		roseMap.put("movie4", 3.5);
		roseMap.put("movie5", 4.5);
		roseMap.put("movie6", 5.0);
		dataset.put("zhouzhou", roseMap);
		
		
		// 初始化谢少数据集
		
		Map<String, Double> xczMap = new HashMap<String, Double>();
		xczMap.put("movie1", 4.5);
		xczMap.put("movie3", 2.5);
		xczMap.put("movie5", 1.0);
		xczMap.put("movie7", 4.5);
		xczMap.put("movie9", 4.5);
		xczMap.put("movie2", 2.0);
		dataset.put("xcz", xczMap);


		// 初始化qfg 数据集
		
		Map<String, Double> qfgMap = new HashMap<String, Double>();
		qfgMap.put("movie2", 3.0);
		qfgMap.put("movie3", 3.5);
		qfgMap.put("movie4", 1.5);
		qfgMap.put("movie5", 5.0);
		qfgMap.put("movie7", 3.5);
		qfgMap.put("movie9", 3.0);
		dataset.put("qfg", qfgMap);
		
		Map<String, Double> LyfMap = new HashMap<String, Double>();
		LyfMap.put("movie1", 0.5);
		LyfMap.put("movie2", 1.5);
		LyfMap.put("movie3", 4.5);
		LyfMap.put("movie4", 0.5);
		LyfMap.put("movie5", 4.5);
		LyfMap.put("movie7", 2.0);
		LyfMap.put("movie9", 2.0);
		dataset.put("lyf", LyfMap);
		
		Map<String, Double> hanhanMap = new HashMap<String, Double>();
		hanhanMap.put("movie1", 3.5);
		hanhanMap.put("movie2", 2.5);
		hanhanMap.put("movie3", 1.0);
		hanhanMap.put("movie4", 3.5);
		hanhanMap.put("movie5", 4.5);
		hanhanMap.put("movie7", 5.0);
		hanhanMap.put("movie8", 5.0);
		dataset.put("hanhan", hanhanMap);
		

	}
	
	
	public Map<String, Map<String, Double>> getDataSet() {
		return dataset;
	}
	
	// 找出双方都评论过的电影，进行用户之间的相似度计算
	public double sim_pearson(String person1, String person2) {
		// 找出双方都评论过的电影,（皮尔逊算法要求）
		List<String> list = new ArrayList<String>();
		for (Entry<String, Double> p1 : dataset.get(person1).entrySet()) {
		if (dataset.get(person2).containsKey(p1.getKey())) {
		list.add(p1.getKey());
		}
		}


		double sumX = 0.0;
		double sumY = 0.0;
		double sumX_Sq = 0.0;
		double sumY_Sq = 0.0;
		double sumXY = 0.0;
		int N = list.size();


		for (String name : list) {
		Map<String, Double> p1Map = dataset.get(person1);
		Map<String, Double> p2Map = dataset.get(person2);


		sumX += p1Map.get(name);
		sumY += p2Map.get(name);
		sumX_Sq += Math.pow(p1Map.get(name), 2);
		sumY_Sq += Math.pow(p2Map.get(name), 2);
		sumXY += p1Map.get(name) * p2Map.get(name);
		}


		double numerator = sumXY - sumX * sumY / N;
		double denominator = Math.sqrt((sumX_Sq - sumX * sumX / N)
		* (sumY_Sq - sumY * sumY / N));


		// 分母不能为0
		if (denominator == 0) {
		return 0;
		}


		return numerator / denominator;
		}
     
	
      
	

}

