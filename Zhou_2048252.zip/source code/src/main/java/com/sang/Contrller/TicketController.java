package com.sang.Contrller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.sang.model.Contact;
import com.sang.model.Ticket;
import com.sang.service.ContactService;
import com.sang.service.TicketService;


@RestController
public class TicketController {
	//contact controller层 控制contact的后台代码
	@Autowired
	TicketService tts;
	@GetMapping("/xuanzuo")
		public ModelAndView contact(){
	        ModelAndView mv = new ModelAndView("xuanzuo");
	        
	        return mv;
	    }
    @RequestMapping("/xuanzuo")
	//@RequestParam("username") String username,@RequestParam("password") String userpassword
	    public ModelAndView contact(HttpServletRequest request,Model model, HttpSession session){
	      
		 
		   String string = (String)session.getAttribute("username");
		   Ticket t = new Ticket();
		   t.setUserid(string);;
		   SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		   String date = df.format(new Date());
		   System.out.println(date);
		   t.setDate(date);
		   t.setUri("Two-screens.jpg");
		   tts.add(t);
		////   t.setMoive(request.getParameter("moive"));
		//   t.setSitecol(request.getParameter("sitecol"));
		 //  t.setSiterow(request.getParameter("siterow"));
	      // model.addAttribute("msg1", "Thank you for your advice");
		   ModelAndView mv = new ModelAndView("Newinformation");
		   return mv;   
		
			   
	
	
			   }
    
 

}