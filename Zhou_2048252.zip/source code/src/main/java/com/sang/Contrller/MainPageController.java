package com.sang.Contrller;

import java.util.ArrayList;
import java.util.List;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.sang.service.*;

import com.sang.model.Moive;
import com.sang.model.User;

@RestController
public class MainPageController {
	@Autowired
	MovieService ts;
	@GetMapping("/indexs")
		public ModelAndView index(Model model){
		List<Moive> list = new ArrayList<>();
	    
		list = ts.getAll();
//		System.out.println(list);
//		list.get(0).getView();
//		list.get(0).getBooking();
//		list.get(0).getDate();
//		System.out.print(list.get(0).getView());
		List<Moive> list2 = new ArrayList<>();
		//double[] hotnumber = new double[1000];
		int listlength = list.size();	
		for(int i=0;i<listlength;i++) {
			int booking = Integer.parseInt(list.get(i).getBooking());
			int view = Integer.parseInt(list.get(i).getView());
			int date = Integer.parseInt(list.get(i).getDate());
		double hotnumber = booking * 0.3 + view * 0.6 + date* 0.1;
		Moive mv = new Moive();
		mv.setId(i);
		mv.setHotnumber(hotnumber);
		list2.add(mv);
		}
//		System.out.println(list2.get(0).getId());
//		System.out.println(list2.get(0).getHotnumber());
//		System.out.println(list2.get(1).getId());
//		System.out.println(list2.get(1).getHotnumber());
//		System.out.println(list2.get(2).getId());
//		System.out.println(list2.get(2).getHotnumber());
//		System.out.println(list2.get(3).getId());
//		System.out.println(list2.get(3).getHotnumber());
		
		//对求出来的 热度值列表进行排序 
		for(int i=0;i<list2.size()-1;i++)
            for(int j=0;j<list2.size()-1-i;j++) {
                if(list2.get(j).getHotnumber()> list2.get(j+1).getHotnumber()) {
                	int id = list2.get(j).getId();
                	double hotnumber = list2.get(j).getHotnumber();
                	list2.get(j).setId(list2.get(j+1).getId());
                	list2.get(j).setHotnumber(list2.get(j+1).getHotnumber());
                	list2.get(j+1).setId(id);
                	list2.get(j+1).setHotnumber(hotnumber);
                }
           }
		//获取前5部电影
//		List<Moive> list3 = new ArrayList<>();
//		for(int m=0;m<5;m++) {
//			list3.get(m).setId(list2.get(m).getId());
//			list3.get(m).setName(list2.get(m).getName());
//		}
//		model.addAttribute("list3",list3);
		System.out.println("////////////////////////");
		System.out.println(list2.get(0).getId());
		System.out.println("////////////////////////");
		System.out.println(list2.get(0).getHotnumber());
		System.out.println(list2.get(1).getId());
		System.out.println(list2.get(1).getHotnumber());
		System.out.println(list2.get(2).getId());
		System.out.println(list2.get(2).getHotnumber());
		System.out.println(list2.get(3).getId());
		System.out.println(list2.get(3).getHotnumber());
		
	    ModelAndView mv = new ModelAndView("index");
//	    mv.addObject(model);
	        return mv;
	    }
 /*   @RequestMapping("/index")

	    public ModelAndView Login(HttpServletRequest request,Model model, HttpSession session){
	      
			int vali=3;
			   User u = new User();
			   u.setUsername(request.getParameter("username"));
		
			   u.setPassword(request.getParameter("password"));
		

				 ModelAndView mv = new ModelAndView("login");
				 return mv;   
		
			   
	
	
			   }*/
     public int validate(User u) {
    	 if(u.getPassword()==null&&u.getUsername()==null) {
    		 return 1;
    	 }else {
    		 return 0;
    	 }
     }
     public double gethotnumber(int book,int view ,int date) {
    	 double hotnumber = 0 ;
    	 hotnumber = book * 0.3 + view * 0.6 + date * 0.1 ;
    	 return hotnumber;
     }
  

}