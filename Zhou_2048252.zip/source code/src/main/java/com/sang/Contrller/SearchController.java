package com.sang.Contrller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.sang.model.Moive;
import com.sang.service.MovieService;
import com.sang.service.TicketService;

@RestController
public class SearchController {
	@Autowired
	MovieService mv;
	  @PostMapping("/searchmoive")
		//@RequestParam("username") String username,@RequestParam("password") String userpassword
		    public ModelAndView searchmoive(HttpServletRequest request,Model model, HttpSession session){
	
		  String moiveinfo = request.getParameter("searchinfo");
		  System.out.println("输入的信息");
		  System.out.println(moiveinfo);
		  List<Moive> list = new ArrayList<Moive>();
		  if(moiveinfo.equals("Sci-Fi")||moiveinfo.equals("Action")||moiveinfo.equals("Comedy")||moiveinfo.equals("Horror")) {
			  System.out.print("搜索的为 GENRE");
			  list = mv.searchbygenre(moiveinfo);
			  model.addAttribute("list", list);
			  ModelAndView mv = new ModelAndView("search2");
		      return mv;
		  }else {
			  System.out.print("搜索的为 MovieName");
			  list = mv.searchbyname(moiveinfo);
			  model.addAttribute("list", list);
			  ModelAndView mv = new ModelAndView("search2");
		      return mv;
		  }
		
	  }
}
