package com.sang.Contrller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.sang.Dao.TicketDao;
import com.sang.model.Moive;
import com.sang.model.Ticket;
import com.sang.model.User;
import com.sang.service.Loginservice;


@RestController
public class Information3Controller {
	//contact controller层 控制contact的后台代码
	@Autowired
	TicketDao tq;
	@RequestMapping("/information3")
		public ModelAndView information(HttpSession session,Model model){
		   String userid = (String)session.getAttribute("username");
			List<Ticket> lists = new ArrayList<>();
		    lists = tq.search(userid);
		    System.out.print(lists);
			model.addAttribute("lists",lists);
	        ModelAndView mv = new ModelAndView("information3");
	        return mv;
	    }
  /*  @RequestMapping("/information3")
	   public ModelAndView contact(HttpServletRequest request,Model model, HttpSession session){
		      
			 
		   String s = (String)session.getAttribute("username");
		  
				  ModelAndView mv = new ModelAndView("information3");
					 return mv;   
			  }
		      
		 */
			  
				
			   
	
	
			   }
    
 

