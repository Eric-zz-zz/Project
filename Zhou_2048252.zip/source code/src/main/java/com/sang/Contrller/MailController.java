package com.sang.Contrller;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sang.service.MailService;

@Controller
public class MailController {
    @Autowired
    private MailService mailService;
 
    @PostMapping("/mail")
    @ResponseBody
    public Map<Object,Object> getCheckCode(String email,HttpServletRequest request, HttpSession session){
    	 Map<Object,Object> map = new HashMap<Object, Object>();
    	email = request.getParameter("email");
    	System.out.println(email);
        String checkCode = String.valueOf(new Random().nextInt(899999) + 100000);
        session.setAttribute("code", checkCode);
        System.out.println(checkCode);
        String message = "Hello! Fuck man,you checkCode is："+checkCode;
        try {
            mailService.sendSimpleMail(email, "Hello~ your checkCode", message);
        }catch (Exception e){
            return map;
        }
        map.put("status","100");
        return map;
    }
}