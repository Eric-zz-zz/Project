package com.sang.Contrller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


import com.sang.model.Moive;

import com.sang.service.MovieService;
@RestController
public class ListController {
	
		@Autowired
		MovieService mmm;	
		@GetMapping("/list")
			public ModelAndView index(Model model){
			List<Moive> lists = mmm.getAll();
			model.addAttribute("lists", lists);
		        ModelAndView mv = new ModelAndView("list");
		        return mv;
		    }
}
