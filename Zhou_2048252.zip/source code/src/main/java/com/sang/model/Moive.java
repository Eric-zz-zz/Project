package com.sang.model;

import lombok.Data;


public class Moive {

	private int id;
	private String view;//浏览量
	
	private String booking;//顶票量
	
	private String  date;//天数
	
	private String name; //电影名
	
	private String uri;  //路径
	
	private double Hotnumber;

	private String genre;

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public double getHotnumber() {
		return Hotnumber;
	}

	public void setHotnumber(double hotnumber) {
		Hotnumber = hotnumber;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getView() {
		return view;
	}

	public void setView(String view) {
		this.view = view;
	}

	public String getBooking() {
		return booking;
	}

	public void setBooking(String booking) {
		this.booking = booking;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}
	
	
}
