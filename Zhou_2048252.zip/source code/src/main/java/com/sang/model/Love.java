package com.sang.model;

public class Love {
	private int id;
	private String time;
	private String moive;
	private String username;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getMoive() {
		return moive;
	}
	public void setMoive(String moive) {
		this.moive = moive;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}

}
