package com.sang.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sang.Dao.ContactDao;
import com.sang.Dao.LoveDao;
import com.sang.model.Contact;
import com.sang.model.Love;
import com.sang.model.User;


@Service
public class LoveService {
	//contact服务层 方法
	@Autowired
	LoveDao love;
	//add
	public void newmsg(Love news) {
		love.newmsg(news);
	}
	   public List<Love> getAll(String useranme){
		   return love.getAll(useranme);
	   }

}
