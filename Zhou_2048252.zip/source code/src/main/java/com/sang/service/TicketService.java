package com.sang.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sang.Dao.MoiveDao;
import com.sang.Dao.TicketDao;
import com.sang.model.Contact;
import com.sang.model.Moive;
import com.sang.model.Ticket;
import com.sang.model.User;



@Service
public class TicketService {
	@Autowired
	  TicketDao t;
	public void add(Ticket c) {
		t.add(c);
	}
	 public List<Ticket> search(String username){
	       return t.search(username);
	   }
}
