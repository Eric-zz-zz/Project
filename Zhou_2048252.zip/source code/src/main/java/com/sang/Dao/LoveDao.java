package com.sang.Dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.sang.model.Contact;
import com.sang.model.Love;
import com.sang.model.User;

@Mapper
public interface LoveDao {

	void newmsg(Love news);
	//查询所有的shoucang
    List<Love> getAll(String username);
}
