package com.sang.Dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.sang.model.Moive;
//import com.sang.model.User;

@Mapper
public interface MoiveDao {
	List<Moive> getAll();
	//查找电影方式 1 or 2
    //方式1 根据名字的模糊搜索
	List<Moive> searchbyname(String name);
	//方式2 根据电影类型进行准确搜索
	List<Moive> searchbygenre(String genre);
	
}
