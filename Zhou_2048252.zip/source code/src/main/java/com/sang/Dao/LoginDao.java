package com.sang.Dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.sang.model.Contact;
import com.sang.model.User;



@Mapper
public interface LoginDao {
	
	//查询所有的人
List<User> getAll();

//登陆
//注册
void newuser(User u);
void newuser2(User u);
User getPersonByname(String name);
void updateuser(User u);
void deleteuser(int id);
String getpassword(String name);
String findUserById(String id);
}
