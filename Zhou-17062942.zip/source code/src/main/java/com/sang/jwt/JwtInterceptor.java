package com.sang.jwt;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.sang.model.User;
import com.sang.service.Loginservice;

@Component
public class JwtInterceptor implements HandlerInterceptor {
	String s1=null;
	String s2=null;
    @Autowired
    //SysUserService sysUserService;
    Loginservice ls;
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 从 http 请求头中取出 token
    	//获得cookie数组
    Cookie[] cookies = request.getCookies();
    	if(cookies != null && cookies.length > 0){
    	     for (Cookie cookie : cookies){
    	    	 if(cookie.getName().equals("tokenjwt")) {
    	    		s1 = cookie.getValue();
    	    		 System.out.println("相等后"+s1);
    	    	 }else if(cookie.getName()!="tokenjwt") {
    	    		s2=cookie.getValue();
//    	    	  System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1");
//       	    	  System.out.println(cookie.getName());
//       	    	  System.out.println(cookie.getValue());
//       	    	  System.out.println("S1为"+s1);
//       	    	  System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1"); 
//       	    	 System.out.println("S2为"+s2);
    	    	 }

    	     }
    	 }       
        
     String  token = s1;
    //  String token = request.getHeader("token");
      System.out.println(token);
        // 如果不是映射到方法直接通过
        if(!(handler instanceof HandlerMethod)){
            return true;
        }
        if (token != null){
        	 System.out.println("sucess");
            String username = JwtUtil.getUserNameByToken(request);
            // 这边拿到的 用户名 应该去数据库查询获得密码，简略，步骤在service直接获取密码
            User u = new User();
            u = ls.getPersonByname(username);
           
            boolean result = JwtUtil.verify(token,username,u.getPassword());
            if(result){
                System.out.println("通过拦截器");
                return true;
            }
        }
        return false;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

    }
}