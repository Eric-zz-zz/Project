package com.sang.Dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.sang.model.Moive;
import com.sang.model.Ticket;
//import com.sang.model.User;

@Mapper
public interface TicketDao {

	void add(Ticket t);
	List<Ticket> search(String username);
}
