package com.sang.Dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.sang.model.Contact;


@Mapper
public interface ContactDao {
//contact接口类 方法
	void newmsg(Contact c);
	List<Contact> getAll();
}
