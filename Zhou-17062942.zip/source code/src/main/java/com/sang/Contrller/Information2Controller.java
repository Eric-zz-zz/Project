package com.sang.Contrller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.sang.model.User;
import com.sang.service.Loginservice;


@RestController
public class Information2Controller {
	//contact controller层 控制contact的后台代码
	@Autowired
	Loginservice t;
	@GetMapping("/information2")
		public ModelAndView information(){
	        ModelAndView mv = new ModelAndView("information2");
	        
	        return mv;
	    }
    @RequestMapping("/information2")
	   public ModelAndView contact(HttpServletRequest request,Model model, HttpSession session){
		      
			 
		   String s = (String)session.getAttribute("username");
		  
				  ModelAndView mv = new ModelAndView("Newinformation");
					 return mv;   
			  }
		      
		 
			  
				
			   
	
	
			   }
    
 

