package com.sang.Contrller;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class AcrchiveController {
	
	
	 
	@RequestMapping("/test")
		public ModelAndView back(){
	//String token = (String)session.getAttribute("token");
	//  response.setHeader("token",token);
	  ModelAndView mv = new ModelAndView("test");
      return mv;
	    }
	@RequestMapping("/search")
	public ModelAndView search(){
//String token = (String)session.getAttribute("token");
//  response.setHeader("token",token);
  ModelAndView mv = new ModelAndView("search");
  return mv;
    }
	@RequestMapping("/search2")
	public ModelAndView search2(){
//String token = (String)session.getAttribute("token");
//  response.setHeader("token",token);
  ModelAndView mv = new ModelAndView("search2");
  return mv;
    }
	@RequestMapping("/map")
	public ModelAndView map(){
//String token = (String)session.getAttribute("token");
//  response.setHeader("token",token);
  ModelAndView mv = new ModelAndView("map");
  return mv;
    }
	@RequestMapping("/index")
	public ModelAndView index(){
//String token = (String)session.getAttribute("token");
//  response.setHeader("token",token);
  ModelAndView mv = new ModelAndView("index");
  return mv;
    }
	 @RequestMapping("/test2")
		public ModelAndView test2(){
		/*	String string = (String)session.getAttribute("token");
			if(string!=null) {
		        ModelAndView mv = new ModelAndView("test2");
		        return mv;}
			else {
				ModelAndView mv = new ModelAndView("token");
		        return mv;
			}*/ModelAndView mv = new ModelAndView("test2");
	        return mv;
	       
	    }
	 @RequestMapping("/token")
		public ModelAndView token(){
	        ModelAndView mv = new ModelAndView("token");
	        return mv;
	    }
	 @GetMapping("/mail")
		public ModelAndView mail(){
	        ModelAndView mv = new ModelAndView("mail");
	        return mv;
	    }
	 @GetMapping("/Newinformation2")
		public ModelAndView Newinformation2(){
	        ModelAndView mv = new ModelAndView("Newinformation2");
	        return mv;
	    }
	 @GetMapping("/information4")
		public ModelAndView Newinformation44(){
	        ModelAndView mv = new ModelAndView("information4");
	        return mv;
	    }
	 @GetMapping("/information5")
		public ModelAndView Newinformation4554(){
	        ModelAndView mv = new ModelAndView("information5");
	        return mv;
	    }
	 /*@RequestMapping("/index")
		public ModelAndView index(){
	        ModelAndView mv = new ModelAndView("index");
	        return mv;
	    }*/
}
