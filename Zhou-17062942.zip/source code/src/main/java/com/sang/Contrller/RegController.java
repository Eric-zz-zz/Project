package com.sang.Contrller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.sang.service.*;
import com.sang.model.User;

@RestController
public class RegController {
	@Autowired
	Loginservice ts;
	 @Autowired
	 MailService mailService;
	@GetMapping("/register")
		public ModelAndView index(){
	        ModelAndView mv = new ModelAndView("register");
	        return mv;
	    }
    @PostMapping("/register2")
	//@RequestParam("username") String username,@RequestParam("password") String userpassword
	    public Map<Object,Object> Login(HttpServletRequest request,Model model, HttpSession session){
	      Map<Object, Object> map = new HashMap<Object, Object>();
	      
		
			   User u = new User();
			   u.setUsername(request.getParameter("username"));
			   u.setPassword(request.getParameter("password"));
			   String checkcode = (request.getParameter("checkcode"));
		     System.out.println(u.getUsername());
		     System.out.println(u.getPassword());
		 
		     String code = (String)session.getAttribute("code");
		     
		     System.out.println(checkcode);
		     System.out.println(code);
		     if(u.getUsername().equals(null)||u.getPassword().equals(null)) {
		    	   
				    	 map.put("status","200");
				    	 
		     }else{
		    	 if(code .equals(checkcode) ) {
			    	 map.put("status","100");
			    	 ts.newp(u);
			     }else {
			    	 map.put("status","200");
			    	 
			     }
		     }
		  
		     
		    	
		     return map;
			
			
			
		
			   
	
	
			   }
      	
 

}