package com.sang.Contrller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.sang.model.User;
import com.sang.service.Loginservice;


@RestController
public class NewinformationController {


	@GetMapping("/Newinformation")
		public ModelAndView Newinformation(){
	        ModelAndView mv = new ModelAndView("Newinformation");
	        
	        return mv;
	    }
	  @PostMapping("/addresssubmit")
	   public ModelAndView  addresssubmit  (HttpServletRequest request,Model model, HttpSession session){
		      
			 Map<Object,Object> map = new HashMap<Object,Object>();
			 String number = request.getParameter("number");
			 System.out.print(number);
			/* if(number.equals(null)) {
				 map.put("status","200");
			 }else {
				 map.put("status", "100");
			 }*/
			 ModelAndView mv = new ModelAndView();
			 if(number.equals(null)) {
		    mv.setViewName("Newinformation2");
			 }else {
		    mv.setViewName("Newinformation");
			 }
		    return mv;
	 
			  }
   
		 
			  
				
			   
 }
    
 

