package com.sang.Contrller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.sang.model.Contact;
import com.sang.model.Love;
import com.sang.model.Moive;
import com.sang.service.ContactService;
import com.sang.service.LoveService;


@RestController
public class LoveController {
	//contact controller层 控制contact的后台代码
	@Autowired
    LoveService service;
	@PostMapping("/addlove")
		public Map<Object,Object> get(HttpServletRequest request,HttpSession session){
	    Map<Object,Object> map = new HashMap<Object,Object>();
		String moive = request.getParameter("GetData");
		String test = request.getParameter("GetData2");
		System.out.println(test+"sssssssssssssss");
		System.out.println("Get the moive name fromhmtl:");
		System.out.println(moive);
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		String date = df.format(new Date());
		System.out.println("date:");
		System.out.println(date);
		Love love = new Love();
		love.setMoive(moive);
		love.setTime(date);
		String string = (String)session.getAttribute("username");
		love.setUsername(string);
		service.newmsg(love);
		map.put("status","100");
		return map;
	    }
	@GetMapping("/shoucang")
	public ModelAndView index(Model model,HttpSession session){
    String username = (String)session.getAttribute("username");
    List<Love> lists = new ArrayList<>();
	lists=service.getAll(username);
	model.addAttribute("lists", lists);
        ModelAndView mv = new ModelAndView("shoucang");
        return mv;
    }
    
 

}