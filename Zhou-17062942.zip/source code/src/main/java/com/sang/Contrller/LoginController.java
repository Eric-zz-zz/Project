package com.sang.Contrller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.sang.service.*;
//import com.sang.jwt.JwtUtil;
import com.sang.model.User;

@RestController
public class LoginController {
	@Autowired
	Loginservice ls;
	@GetMapping("/login")
		public ModelAndView login(){
	        ModelAndView mv = new ModelAndView("login");
	        return mv;
	    }
    @RequestMapping("/login")
	//@RequestParam("username") String username,@RequestParam("password") String userpassword
	    public ModelAndView Login(Map<String, Object> map,HttpServletRequest request, Model model,HttpSession session,HttpServletResponse response){
	      
			int vali=3;
			   User u = new User();
			   u.setUsername(request.getParameter("username"));
			   u.setPassword(request.getParameter("password"));
			
			   User u2 = new User();
			   u2 = ls.getPersonByname(u.getUsername());
	 
		//	   System.out.println(u2.getUsername());
		//	   System.out.println(u2.getPassword());
		  //     session.setAttribute("name", 1);
			   if(u2.getPassword()!=null&&u2.getUsername()!=null) {
				   if(u.getPassword().equals(u2.getPassword())) {
					 session.setAttribute("username", request.getParameter("username")); 
					   
					 // session.setAttribute("token", token); 
					// String token = JwtUtil.sign(u2.getUsername(),u2.getPassword());
					//   response.setHeader("token",token);
					  
					 
					   
					   String token2 = request.getHeader("token");
					   
					   
				//	   session.setAttribute("token", token);
					
					   
				//	   Cookie cookie = new Cookie("tokenjwt", token);
				//	   cookie.setMaxAge(3600);
			      //     cookie.setDomain("localhost");
			     //      cookie.setPath("/");
			        //   response.addCookie(cookie);
					//
					   ModelAndView mv = new ModelAndView("index");
					
					    return mv;
					   }else if(!u.getPassword().equals(u2.getPassword())){
					 //      model.addAttribute("msg", "密码错误");
						   ModelAndView mv = new ModelAndView("login");
						   model.addAttribute("msg1", "wrongpassword");
					        return mv;   
					   }else {
						   ModelAndView mv = new ModelAndView("login");
						   model.addAttribute("msg1", "wrongpassword");
					        return mv;   
					   }
			   }else {
				   ModelAndView mv = new ModelAndView("login");
				   model.addAttribute("msg1", "wrongpassword");
			        return mv; 
			   }
			   
	
	
			   }
     public int validate(User u) {
    	 if(u.getPassword()==null&&u.getUsername()==null) {
    		 return 1;
    	 }else {
    		 return 0;
    	 }
     }
        	
 

}