package com.sang.Contrller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.sang.model.Contact;
import com.sang.service.ContactService;


@RestController
public class ContactController {
	//contact controller层 控制contact的后台代码
	@Autowired
	ContactService ts;
	@GetMapping("/contact")
		public ModelAndView contact(){
	        ModelAndView mv = new ModelAndView("contact");
	        
	        return mv;
	    }
    @RequestMapping("/contact")
	//@RequestParam("username") String username,@RequestParam("password") String userpassword
	    public ModelAndView contact(HttpServletRequest request,Model model, HttpSession session){
	      
		 
		   String string = (String)session.getAttribute("username");
			Contact c  = new Contact();
			c.setUsername(string);
			c.setEmail(request.getParameter("email"));
			c.setPhone(request.getParameter("phone"));
			c.setName(request.getParameter("name"));
			c.setContact(request.getParameter("contact"));
			ts.newmsg(c);
			 System.out.println("？？？？？？？");
			 System.out.print(request.getParameter("email")); 
			 System.out.println("？？？？？？？");
			 System.out.print(request.getParameter("name")); 
			 System.out.println("？？？？？？？");
			 System.out.print(request.getParameter("p")); 
			   
		
			   model.addAttribute("msg1", "Thank you for your advice");
				 ModelAndView mv = new ModelAndView("contact");
				 return mv;   
		
			   
	
	
			   }
    
 

}