package com.sang.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sang.Dao.LoginDao;
import com.sang.model.User;


@Service
public class Loginservice {
	@Autowired
   LoginDao test;
   public List<User> getAll(){
	   return test.getAll();
   }
   
   //登陆注册
   public void newp(User p){
      test.newuser(p);
   }
   public void newp2(User p){
	      test.newuser2(p);
	   }
   public User getPersonByname(String name){
       return test.getPersonByname(name);
   }
   public void upadateuser(User u) {
	   test.updateuser(u);
   }
   public void deleteuser(int id) {
	   test.deleteuser(id);
   }
   public String getpassword(String name){
       return test.getpassword(name);
   }
   public String findUserById(String id) {
	   return test.findUserById(id);
	   
   }




}
