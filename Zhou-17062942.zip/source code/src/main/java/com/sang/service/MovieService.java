package com.sang.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sang.Dao.MoiveDao;
import com.sang.model.Moive;
import com.sang.model.User;



@Service
public class MovieService {
	@Autowired
	  MoiveDao mv;
	 public List<Moive> getAll(){
		   return mv.getAll();
	   }
	 public List<Moive> searchbyname(String name){
		 return mv.searchbyname(name);
		 
	 }
	 public List<Moive> searchbygenre(String genre){
		 return mv.searchbygenre(genre);
	 }
}
