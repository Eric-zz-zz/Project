package com.sang.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sang.Dao.ContactDao;
import com.sang.model.Contact;


@Service
public class ContactService {
	//contact服务层 方法
	@Autowired
	ContactDao cd;
	//add
	public void newmsg(Contact c) {
		cd.newmsg(c);
	}
	//查询所有contact
	 public List<Contact> getAll(){
		   return cd.getAll();
	   } 
}
