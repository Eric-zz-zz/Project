package com.sang.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//zhouzhou qfg lyf xcz hanhan
		List<String> list = new ArrayList<>();
		List<UserRemark> simnumList = new ArrayList<>();
		list.add("zhouzhou");
		list.add("qfg");
		list.add("lyf");
		list.add("xcz");
		list.add("hanhan");
	      RecommendTest test = new RecommendTest();
	      for(int i=0;i<list.size();i++) {
	    	  UserRemark Psort = new UserRemark();
	    	  if(list.get(i).equals("zhouzhou")) {
	    		  System.out.println("同一个人跳过");
	    	  }else {
	    	   
	    		double num =test.sim_pearson("zhouzhou",list.get(i));
	  	  	    System.out.println("zhouzhou与"+list.get(i)+"的相似度为:"+num);
	  	  	    Psort.setSimnum(num);
	  	  	    Psort.setUserid(list.get(i));
	  	     	System.out.println("得到的新的人"+Psort.getUserid());
	  	    	System.out.println("得到的新的人的相似度"+Psort.getSimnum());   
	  	    	simnumList.add(Psort);
	    	  }
	    	 
	  	    
	      }
	      for(int m=0;m<simnumList.size();m++) {
	    		System.out.println("得到新列表"+simnumList.get(m).getUserid());   
		  		System.out.println("得到新列表"+simnumList.get(m).getSimnum());   
	    	}
	      
	  	for(int i=0;i<simnumList.size()-1;i++)
            for(int j=0;j<simnumList.size()-1-i;j++) {
                if(simnumList.get(j).getSimnum()<simnumList.get(j+1).getSimnum()) {
                	int id = simnumList.get(j).getId();
                	double hotnumber = simnumList.get(j).getSimnum();
                	simnumList.get(j).setId(simnumList.get(j+1).getId());
                	simnumList.get(j).setSimnum(simnumList.get(j+1).getSimnum());
                	simnumList.get(j+1).setId(id);
                	simnumList.get(j+1).setSimnum(hotnumber);
                }
           }
	     
	 for(int m=0;m<simnumList.size();m++) {
	    		System.out.println("得到排序后的列表"+simnumList.get(m).getUserid());   
		  		System.out.println("得到排序后的列表"+simnumList.get(m).getSimnum());   
	    	}
	 //根据协同过滤原则 给用户周周推荐电影
	 for(int m=0;m<2;m++) {
		 
		 System.out.println("根据协同过滤推荐给zhouzhou的相同癖好的用户为:"+simnumList.get(m).getUserid());
	 }
	 
	    
	}

}
