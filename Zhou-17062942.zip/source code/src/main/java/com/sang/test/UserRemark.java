package com.sang.test;

public class UserRemark {

	private int id;
	private String userid;
	private String Moiveid;
	private  String rate;
	private Double simnum;
	
	public Double getSimnum() {
		return simnum;
	}
	public void setSimnum(Double simnum) {
		this.simnum = simnum;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getMoiveid() {
		return Moiveid;
	}
	public void setMoiveid(String moiveid) {
		Moiveid = moiveid;
	}
	public String getRate() {
		return rate;
	}
	public void setRate(String rate) {
		this.rate = rate;
	}

	
}
