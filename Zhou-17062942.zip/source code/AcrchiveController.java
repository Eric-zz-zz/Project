package com.sang.Contrller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class AcrchiveController {
	
	 @RequestMapping("/index")
		public ModelAndView index(HttpSession session){
		   String string = (String)session.getAttribute("username");
		   System.out.print(string);
	        ModelAndView mv = new ModelAndView("index");
	        return mv;
	    }
	 
	@RequestMapping("/back")
		public ModelAndView back(){
	        ModelAndView mv = new ModelAndView("back");
	        return mv;
	    }
	/* @RequestMapping("/test")
		public ModelAndView test(){
	        ModelAndView mv = new ModelAndView("test");
	        return mv;
	    }*/
	
}
